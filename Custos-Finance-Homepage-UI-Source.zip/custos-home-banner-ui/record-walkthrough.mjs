import playwright from "file:///F:/Playground/.codex-temp-playwright/node_modules/playwright/index.js";

const { chromium } = playwright;

const rootUrl = "http://127.0.0.1:4180";
const outputRoot = "F:/Playground/output";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function animateTo(page, targetY, durationMs) {
  await page.evaluate(
    ({ targetY, durationMs }) =>
      new Promise((resolve) => {
        const startY = window.scrollY;
        const distance = targetY - startY;
        const startedAt = performance.now();
        const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

        const frame = (now) => {
          const progress = Math.min(1, (now - startedAt) / durationMs);
          window.scrollTo(0, Math.round(startY + distance * ease(progress)));
          if (progress < 1) requestAnimationFrame(frame);
          else resolve();
        };

        requestAnimationFrame(frame);
      }),
    { targetY, durationMs },
  );
}

async function selectorY(page, selector, offset = 82) {
  return page.locator(selector).evaluate((element, px) => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    return Math.max(0, Math.min(max, element.getBoundingClientRect().top + window.scrollY - px));
  }, offset);
}

async function record({ name, viewport, videoSize, deviceScaleFactor = 1, selectors, finalPause = 1900 }) {
  const browser = await chromium.launch({
    headless: true,
    executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
  });
  const context = await browser.newContext({
    viewport,
    deviceScaleFactor,
    recordVideo: { dir: `${outputRoot}/raw-recordings`, size: videoSize },
    reducedMotion: "no-preference",
    colorScheme: "dark",
  });
  const page = await context.newPage();
  await page.goto(rootUrl, { waitUntil: "networkidle" });
  await page.addStyleTag({ content: "*{scrollbar-width:none!important}::-webkit-scrollbar{display:none!important}" });
  await page.evaluate(() => window.scrollTo(0, 0));
  await sleep(2400);

  for (const marker of selectors) {
    const y = marker === "__bottom__"
      ? await page.evaluate(() => document.documentElement.scrollHeight - window.innerHeight)
      : await selectorY(page, marker.selector, marker.offset ?? 82);
    await animateTo(page, y, marker.travelMs ?? 1650);
    await sleep(marker.pauseMs ?? 2000);
  }

  await sleep(finalPause);
  const video = page.video();
  await page.close();
  await context.close();
  if (!video) throw new Error(`No recording was created for ${name}`);
  const outputPath = `${outputRoot}/${name}.webm`;
  await video.saveAs(outputPath);
  await browser.close();
  return outputPath;
}

const mode = process.argv[2] ?? "all";
let horizontal = null;
let vertical = null;

if (mode === "all" || mode === "horizontal") horizontal = await record({
  name: "Custos-Finance-Homepage-Tour-16x9-Silent",
  viewport: { width: 1920, height: 1080 },
  videoSize: { width: 1920, height: 1080 },
  selectors: [
    { selector: "#system", pauseMs: 2400 },
    { selector: "#markets", pauseMs: 2400 },
    { selector: "#proof", pauseMs: 2400 },
    { selector: "#season", pauseMs: 2400 },
    "__bottom__",
  ],
});

if (mode === "all" || mode === "vertical") vertical = await record({
  name: "Custos-Finance-Homepage-Tour-9x16-Silent",
  viewport: { width: 720, height: 1280 },
  videoSize: { width: 720, height: 1280 },
  selectors: [
    { selector: "#system", pauseMs: 1800 },
    { selector: ".layer-card:nth-child(2)", pauseMs: 1600 },
    { selector: ".layer-card:nth-child(3)", pauseMs: 1600 },
    { selector: "#markets", pauseMs: 2000 },
    { selector: "#proof", pauseMs: 2000 },
    { selector: "#season", pauseMs: 2100 },
    "__bottom__",
  ],
});

console.log(JSON.stringify({ horizontal, vertical }));
